import glob
import os
import numpy as np

root = "/home/meili/meili-coor-ions/Ion-Pitzer-1/6wI-/6wI_xyz"
os.chdir(root)

headf = ['19  I-\n']
insertf1 = ['\n']


file_list = glob.glob( root + '/*.xyz')
for fname in file_list:
    # Read the file
    with open(fname,'r') as f:
        fcontent = [line.strip() for line in f]
        #print(fcontent)

    dir_stru = fname.split('/')
    #print(dir_stru)i
    dir_strs = dir_stru[-1].rsplit('.',1)
    #print(dir_strs)
    #m_type = dir_strs[0] # Read the type of the molecule 
    # print(m_type)
    #name_strs =  dir_stru[-1].rsplit('.')
    # print(name_2_strs)
    #fcontent = []
    #for b in filecontent:
    #    fcontent.append(b.strip())
    #a_num = int(fcontent[1].split(' ')[0])
    #print(a_num)
    a_lines = fcontent[1:20] # lines of the atoms
    print(a_lines)
   # type(a_lines[0])
    new_coordinate = []
    for line in a_lines:
        row_content = line.split()
        element = row_content[1]
        #print(element[0:2])
        coord_x, coord_y, coord_z = row_content[2:5]
        print(coord_x,coord_y,coord_z)
        #coordinate_content1[0] = coordinate_content1[0][0:2]
        new_coordinate.append([element[0:2], coord_x, coord_y, coord_z])
    # New name of the file to write  
    new_coord=[]
    for l in new_coordinate:
        new_coord_str=""
        for a in l:
            new_coord_str+="    "
            new_coord_str+=a
            new_coord_str+="    "
        new_coord_str+="\n"
        new_coord.append(new_coord_str)
    print("new_coord:")
    print(new_coord)
    new_content =  headf + insertf1 + new_coord[0:19] 
    # print(new_content)
    new_fname = dir_strs[0] + '.xyz'
    # print(new_fname)
    sav_root = "/home/meili/meili-coor-ions/Ion-Pitzer-1/6wI-/6wI_xyz/"
    with open(sav_root + new_fname,'w') as f:
        f.writelines(new_content)

